
const DummyClients =[
    {
        "name": "John Doe",
        "phone_number": "123-456-7890",
        "address": "123 Main St, Cityville, State, 12345",
        "gender": "Male"
    },
    {
        "name": "Jane Smith",
        "phone_number": "234-567-8901",
        "address": "456 Elm St, Townsville, State, 23456",
        "gender": "Female"
    },
    {
        "name": "Michael Johnson",
        "phone_number": "345-678-9012",
        "address": "789 Oak St, Villageton, State, 34567",
        "gender": "Male"
    },
    {
        "name": "Emily Williams",
        "phone_number": "456-789-0123",
        "address": "987 Pine St, Hamletown, State, 45678",
        "gender": "Female"
    },
    {
        "name": "David Brown",
        "phone_number": "567-890-1234",
        "address": "654 Maple St, Suburbia, State, 56789",
        "gender": "Male"
    },
    {
        "name": "Sarah Taylor",
        "phone_number": "678-901-2345",
        "address": "321 Cedar St, Countryside, State, 67890",
        "gender": "Female"
    },
    {
        "name": "Robert Martinez",
        "phone_number": "789-012-3456",
        "address": "555 Walnut St, Riverside, State, 78901",
        "gender": "Male"
    },
    {
        "name": "Jessica Lee",
        "phone_number": "890-123-4567",
        "address": "777 Birch St, Hillside, State, 89012",
        "gender": "Female"
    },
    {
        "name": "Christopher Clark",
        "phone_number": "901-234-5678",
        "address": "888 Pineapple St, Seaside, State, 90123",
        "gender": "Male"
    },
    {
        "name": "Amanda Scott",
        "phone_number": "012-345-6789",
        "address": "999 Cherry St, Mountainside, State, 01234",
        "gender": "Female"
    }
]
export default DummyClients
