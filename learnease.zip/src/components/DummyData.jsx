const DummyData = [
    {
      id: 'AX781A',
      name: 'Furqan',
      image: 'https://dummyurl.com/avatar1.jpg',
      amount: '1h',
      status: 'Success',
      date: '12-10-2023',
    },
    {
      id: 'BX892B',
      name: 'Alice',
      image: 'https://dummyurl.com/avatar2.jpg',
      amount: '30m',
      status: 'Pending',
      date: '05-25-2023',
    },
    {
      id: 'CX893C',
      name: 'Bob',
      image: 'https://dummyurl.com/avatar3.jpg',
      amount: '20m',
      status: 'pending',
      date: '09-15-2023',
    },
    {
      id: 'DX894D',
      name: 'Charlie',
      image: 'https://dummyurl.com/avatar4.jpg',
      amount: '2h',
      status: 'Success',
      date: '03-08-2023',
    },
    {
      id: 'EX895E',
      name: 'David',
      image: 'https://dummyurl.com/avatar5.jpg',
      amount: '1.5h',
      status: 'Success',
      date: '11-30-2023',
    },
    // Add more entries as needed
    {
      id: 'FX896F',
      name: 'Emily',
      image: 'https://dummyurl.com/avatar6.jpg',
      amount: '10m',
      status: 'Success',
      date: '02-14-2023',
    },
    {
      id: 'GX897G',
      name: 'Frank',
      image: 'https://dummyurl.com/avatar7.jpg',
      amount: '30m',
      status: 'pending',
      date: '07-19-2023',
    },
    {
      id: 'HX898H',
      name: 'Grace',
      image: 'https://dummyurl.com/avatar8.jpg',
      amount: '10m',
      status: 'Success',
      date: '10-05-2023',
    },
    {
      id: 'IX899I',
      name: 'Henry',
      image: 'https://dummyurl.com/avatar9.jpg',
      amount: '30m',
      status: 'Success',
      date: '04-22-2023',
    },
    {
      id: 'JX900J',
      name: 'Isabella',
      image: 'https://dummyurl.com/avatar10.jpg',
      amount: '30m',
      status: 'pending',
      date: '08-17-2023',
    },
    // Add more entries as needed
  ];
  
  export default DummyData;
  